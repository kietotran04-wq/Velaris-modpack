For Alternative White Sandstone Armor 

Just copy the dungeons_and_combat file above and paste it in assets. hit replace all.
repackage and enjoy.

Textures were made by TC_ And Modified by A_Shfox/Me.