<!--
Pack Name: Excalibur | Fresh Animations
Maintainer: GrandPappyJay
Last Updated: 2025-05-19
-->

# 📘 EFA Entity Support Checklist

## 📂 Entity List

- [x] Allay
- [x] Axolotl
- [x] Bee
- [x] Blaze
- [x] Bogged
- [x] Cat
- [x] Cave Spider
- [x] Chicken
- [x] Cow
- [x] Creeper
- [x] Dolphin
- [x] Donkey
- [x] Drowned
- [x] Elder Guardian
- [x] Enderman
- [x] Evoker
- [x] Fox
- [x] Frog
- [x] Ghast
- [x] Giant
- [x] Goat
- [x] Guardian
- [x] Hoglin
- [x] Horse
- [x] Husk
- [x] Illusioner
- [x] Iron Golem
- [x] Llama
- [x] Magma Cube
- [x] Mooshroom
- [x] Mule
- [x] Ocelot
- [x] Parrot
- [x] Phantom
- [x] Pig
- [x] Piglin
- [x] Piglin Brute
- [x] Pillager
- [x] Ravager
- [x] Sheep
- [x] Shulker
- [x] Skeleton
- [x] Skeleton Horse
- [x] Slime
- [x] Sniffer
- [x] Spider
- [x] Stray
- [x] Strider
- [x] Trader Llama
- [x] Turtle
- [x] Vex
- [x] Villager
- [x] Vindicator
- [x] Wandering Trader
- [x] Witch
- [x] Wither Skeleton
- [x] Wolf
- [x] Zoglin
- [x] Zombie
- [x] Zombie Horse
- [x] Zombie Villager
- [x] Zombified Piglin

---

## 📋 Entity Development

| Entity           | EFA (a/b) |  CEM/JPM  |  Texture  | Confirmed | Note      |
|------------------|-----------|-----------|-----------|-----------|-----------|
| Allay            | b         | JPM       | Yes       | EMF       |           |
| Axolotl          | b         |           | Yes       | EMF       |           |
| Bee              | b         |           | Yes       | EMF       |           |
| Blaze            | b         | JPM       | Yes       | EMF       |           |
| Bogged           | b         | CEM       | Yes       | EMF       |           |
| Cat              | b         | JPM       | Yes       | EMF       |           |
| Cave Spider      | b         | JPM       | Yes       | EMF       |           |
| Chicken          | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Cow              | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Creeper          | b         | JPM       | Yes       | EMF       |           |
| Dolphin          | b         |           | Yes       | EMF       |           |
| Donkey           | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Drowned          | b         |           | Yes       | EMF       |           |
| Elder Guardian   | b         |           | Yes       | EMF       |           |
| Enderman         | b         |           | Yes       | EMF       |           |
| Evoker           | b         | JPM       | Yes       | EMF       |           |
| Fox              | b         | JPM       | Yes       | EMF       |           |
| Frog             | b         |           | Yes       | EMF       |           |
| Ghast            | b         |           | Yes       | EMF       |           |
| Giant            | b         |           | Yes       | EMF       |           |
| Goat             | b         |           | Yes       | EMF       |           |
| Guardian         | b         |           | Yes       | EMF       |           |
| Hoglin           | b         |           | Yes       | EMF       |           |
| Horse            | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Husk             | b         |           | Yes       | EMF       |           |
| Illusioner       | b         |           | Yes       | EMF       |           |
| Iron Golem       | b         | JPM       | Yes       | EMF       |           |
| Llama            | b         |           | Yes       | EMF       |           |
| Magma Cube       | b         |           | Yes       | EMF       |           |
| Mooshroom        | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Mule             | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Ocelot           | b         | JPM       | Yes       | EMF       |           |
| Parrot           | b         |           | Yes       | EMF       | 1.21.5 OK |
| Phantom          | b         | CEM       | Yes       | EMF       |           |
| Pig              | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Piglin           | b         |           | Yes       | EMF       |           |
| Piglin Brute     | b         |           | Yes       | EMF       |           |
| Pillager         | b         | JPM       | Yes       | EMF       |           |
| Ravager          | b         | JPM       | Yes       | EMF       |           |
| Sheep            | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Shulker          | b         |           | Yes       | EMF       |           |
| Skeleton         | b         | JPM       | Yes       | EMF       |           |
| Skeleton Horse   | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Slime            | b         | CEM       | Yes       | EMF       |           |
| Sniffer          | b         | CEM       | Yes       | EMF       |           |
| Spider           | b         | JPM       | Yes       | EMF       |           |
| Stray            | b         | JPM       | Yes       | EMF       |           |
| Strider          | b         |           | Yes       | EMF       |           |
| Trader Llama     | b         |           | Yes       | EMF       |           |
| Turtle           | b         |           | Yes       | EMF       |           |
| Vex              | b         | JPM       | Yes       | EMF       |           |
| Villager         | b         | CEM       | Yes       | EMF       |           |
| Vindicator       | b         | JPM       | Yes       | EMF       |           |
| Wandering Trader | b         | CEM       | Yes       | EMF       |           |
| Witch            | b         | JPM       | Yes       | EMF       |           |
| Wither Skeleton  | b         | JPM       | Yes       | EMF       |           |
| Wolf             | b         |           | Yes       | EMF       |           |
| Zoglin           | b         |           | Yes       | EMF       |           |
| Zombie           | b         |           | Yes       | EMF       |           |
| Zombie Horse     | b         | CEM       | Yes       | EMF       | 1.21.5 OK |
| Zombie Villager  | b         | JPM       | Yes       | EMF       |           |
| Zombified Piglin | b         |           | Yes       | EMF       |           |

---

## 🗝️ Miscellaneous

### The Round Table Pack Version Support

| Pack Format | Minecraft Versions | Excalibur | **Clarent** | FA    | **EFA** |
|-------------|--------------------|-----------|-------------|-------|---------|
| 15          | 1.20.0 → 1.20.1    | 1.21.5    | a           | 1.9.2 | a       |
| 18          | 1.20.2             | 1.21.5    | b           | 1.9.2 | b       |
| 22          | 1.20.3 → 1.20.4    | 1.21.5    | b           | 1.9.2 | b       |
| 34          | 1.20.5 → 1.21.1    | 1.21.5    | b           | 1.9.2 | b       |
| 42          | 1.21.2 → 1.21.3    | 1.21.5    | b           | 1.9.3 | b       |
| 46          | 1.21.4             | 1.21.5    | b           | 1.9.3 | b       |
| 55          | 1.21.5             | 1.21.5    | b           | 1.9.3 | b       |

```Fresh Animations support for 1.21.5 is possible with EFA-b```

---
