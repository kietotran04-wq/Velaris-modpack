## All credit to Maffhew for Excalibur

- All textures and models used in this pack are from Excalibur, edits from Excalibur, re-creations of Excalibur assets, or heavily inspired by Excalibur.
- You must have the Excalibur Resource Pack for this Add-On Pack to work properly...
  - Download Excalibur (Maffhew)
    - [Planet Minecraft](https://www.planetminecraft.com/texture-pack/excalibur/)
    - [CurseForge](https://www.curseforge.com/minecraft/texture-packs/excalibur)
    - [Modrinth](https://modrinth.com/resourcepack/excal)

### This Mod Support was created by Starlezz_

---