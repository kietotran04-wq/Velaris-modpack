# Compatibility patch between Excalibur resourcepack and Modern World Creation mod:
════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

  	This compat patch was created and is maintained by Liski the Fox:
        - For this Add-On to work correctly, you must have the Excalibur resourcepack and the Modern World Creation mod installed.
        - Report bugs in the pack to @liski.the.fox in the Excalibur Discord channel.
        - I will make updates to the pack as needed and time permits.

    All credit for the creation of the Excalibur resourcepack goes to Maffhew:
        - Excalibur (Maffhew) resourcepack download links:
            - [Modrinth](https://modrinth.com/resourcepack/excal).
            - [CurseForge](https://www.curseforge.com/minecraft/texture-packs/excalibur).
            - [PlanetMinecraft](https://www.planetminecraft.com/texture-pack/excalibur).

        - Everything included in this pack falls under the Excalibur license because:
            - The assets in this pack are taken from Excalibur.
            - The assets in this pack are an edit of Excalibur assets.
            - The assets in this pack are recreations of Excalibur assets.
            - The assets in this pack are heavily inspired by Excalibur assets.

Special thanks to:
════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

    Maffhew - for the Excalibur resourcepack and permission to maintain the Modern World Creation mod support.
    Keksuccino - for the Modern World Creation mod.

Excalibur license:
════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════

    Excalibur by Matt Dillow (Maffhew) is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
    http://creativecommons.org/licenses/by-nc-nd/3.0/us/

    In other words:
    - You may not redistribute this pack and claim it as your own.
    - You may not redistribute this pack without a link to the official CurseForge or Planet Minecraft Excalibur page.
    - You may not put money-making links such as adf.ly with this work under any circumstances.
    - You may not use this work for commercial purposes.
    - You may not alter, transform, or build upon this work.

    Noncommercial Waiver
    - You may use this Resource Pack as a part of any Minecraft-related video including
	those which are created for commercial purposes or are monetized by advertising,
	as long as there's a direct link to an official Excalibur download page.

    Any of the above conditions can be waived if you get permission from Maffhew.
    Discord: @maffhew
