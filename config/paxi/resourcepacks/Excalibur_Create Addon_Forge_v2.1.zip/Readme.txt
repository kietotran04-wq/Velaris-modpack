1- I included an overlay system for all the Brick variants and the Stone block, and the display board from the main create tab (You can use optifine, connectedness, continuity ...) if these additions do not interest you, delete the "optifine" folder in the "mincecraft" folder in this addon.

			**** Thanks to ****

- Maffhew for making "Excalibur", an awesome resourcepack
- Simibubi the Author of Create
- Craig, who help me to fix some issue
- The discord community of Excalibur, for their feedbacks, their enthusiastic support

			**** Create Excalibur Support License ****

All Rights Reserved

Noncommercial Waiver
- You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
are monetized by advertising, as long as there's a direct link to an official Excalibur and the Create Excalibur Support download page.

If you have any inquires, contact me through Discord.
Discord: @Pablito


			**** Excalibur License ****

Excalibur by Matt Dillow (Maffhew) is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
http://creativecommons.org/licenses/by-nc-nd/3.0/us/

In other words:
- You may not redistribute this pack and claim it as your own.
- You may not redistribute this pack without a link to the official CurseForge or Planet Minecraft Excalibur page.
- You may not put money-making links such as adf.ly with this work under any circumstances.
- You may not use this work for commercial purposes.
- You may not alter, transform, or build upon this work.

Noncommercial Waiver
- You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
are monetized by advertising, as long as there's a direct link to an official Excalibur download page.

Any of the above conditions can be waived if you get permission from Maffhew.
Discord: @maffhew

			**** Installation ****

Ingame

-> Click "Options..."

-> Click "Resource Packs..."

-> Click "Open Resource Pack Folder"

-> Drag and Drop the Create_Excalibur Support.zip file into the "resourcepacks" folder

-> Move the Create Excalibur Support resource pack from the left column to the right

-> Make sure that the support pack is placed above the original Excalibur resource pack

-> Select "Done"

