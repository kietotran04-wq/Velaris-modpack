## All credit to Maffhew for Excalibur

- All textures and models used in this pack are from Excalibur, edits from Excalibur, re-creations of Excalibur assets, or heavily inspired by Excalibur.
- For this addon to work as intended you must use the main Excalibur resource pack.
  - Download Excalibur (Maffhew)
    - [Planet Minecraft](https://www.planetminecraft.com/texture-pack/excalibur/)
    - [CurseForge](https://www.curseforge.com/minecraft/texture-packs/excalibur)
    - [Modrinth](https://modrinth.com/resourcepack/excal)