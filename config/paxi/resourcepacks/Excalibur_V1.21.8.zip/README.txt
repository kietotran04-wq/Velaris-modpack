License:
══════════════════════════════════════════════════════════════════════════

Excalibur by Matt Dillow (Maffhew) is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
http://creativecommons.org/licenses/by-nc-nd/3.0/us/

In other words:
- You may not redistribute this pack and claim it as your own.
- You may not redistribute this pack without a link to the official CurseForge or Planet Minecraft Excalibur page.
- You may not put money-making links such as adf.ly with this work under any circumstances.
- You may not use this work for commercial purposes.
- You may not alter, transform, or build upon this work.

Noncommercial Waiver
- You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
are monetized by advertising, as long as there's a direct link to an official Excalibur download page.

Any of the above conditions can be waived if you get permission from Maffhew.
Discord: @maffhew


Special Thanks To:
══════════════════════════════════════════════════════════════════════════

GrandPappyJay - Various fixes and formatting
TC - Title Logo collaboration, orb.png painting
Brakrel - Pack Icon screenshot
Sven_Smorgasborg - Panorama map
XSSheep - Kitchenware painting
Crescendo - Spirited Away painting
Hoodoo - Optifine cloud skybox
Mizuno - Potted fern, grass clovers


Thank you to the whole community for your inspiration and support. 


Installation: 
══════════════════════════════════════════════════════════════════════════
> Launch Minecraft and click on "Options"

> Click on "Resource Packs"

> Click on "Open Resource Pack Folder"

> Drag the Excalibur.zip file into the resource pack folder
  
> Move the Excalibur resource pack from the left column to the right

> Select "Done" 

> Enter your adventure